function openWith(file) {
    windowLogic.openWindow("Open With");
    document.getElementById("openWithFileInput").value = file;
}